;(function($){
    "use strict";

    /* Document Ready */
    $(document).ready(function () {

    });
    /* Window Load */
    $(window).on('load',function(e){

    });
    /* Window scroll */
    $(window).on('scroll',function (e) {

    });


})(jQuery);